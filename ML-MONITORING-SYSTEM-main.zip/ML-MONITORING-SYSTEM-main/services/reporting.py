import json
from services.advanced_monitor import (
    get_accuracy_trend, get_confusion_matrix, get_data_drift, 
    get_concept_drift, get_latency_trend, get_feature_drift,
    get_class_distribution, get_model_calibration, get_fp_fn_trends
)

def generate_project_report(project_id):
    """
    Compiles a massive 'Deep Report' for the data scientists, compiling all metrics across
    the specific universal project.
    """
    report = {
        "metadata": {
            "project_id": project_id,
            "report_type": "Universal Observability Deep Audit",
        },
        "performance_and_drift": {
            "concept_drift_status": get_concept_drift(project_id),
            "data_drift_confidence": get_data_drift(project_id),
            "input_feature_drift": get_feature_drift(project_id),
        },
        "metrics": {
            "class_distribution": get_class_distribution(project_id),
            "model_calibration_ece": get_model_calibration(project_id),
            "false_positives_negatives": get_fp_fn_trends(project_id)
        }
    }
    return json.dumps(report, indent=4)
