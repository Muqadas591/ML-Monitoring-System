def format_percentage(value):
    return f"{round(value, 2)}%"